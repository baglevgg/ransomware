#!/bin/bash
# SAFE RANSOMWARE DEMO
echo "Your files have been locked."
echo "This is only a harmless demo."
