#include <stdio.h>
int main() {
    printf("Your files have been locked.\n");
    printf("This is a harmless demo.\n");
    return 0;
}
