
# For decryption key recovery

import os
from cryptography.fernet import Fernet

with open("secret.key", "rb") as key_file:
    key = key_file.read()

fernet = Fernet(key)

files = []
for file in os.listdir():
    if file in ["ransomware.py", "secret.key", "crack.py"]:
        continue
    if os.path.isfile(file):
        files.append(file)

print("Files to decrypt:", files)

for file in files:
    with open(file, "rb") as f:
        data = f.read()
    decrypted = fernet.decrypt(data)
    with open(file, "wb") as f:
        f.write(decrypted)

print("Decryption complete.")

