// SAFE RANSOMWARE DEMO
public class Demo {
    public static void main(String[] args) {
        System.out.println("Your files have been locked.");
        System.out.println("This is only a simulation.");
    }
}
