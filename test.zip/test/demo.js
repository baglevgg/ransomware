// SAFE RANSOMWARE DEMO
console.log("Your files have been locked.");
console.log("This is a harmless simulation.");
