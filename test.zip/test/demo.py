# SAFE RANSOMWARE DEMO - DOES NOT ENCRYPT ANYTHING
import time
print("Your files have been locked.")
time.sleep(1)
print("This is only a demo. No real encryption happens here.")
