<?php
// SAFE RANSOMWARE DEMO
echo "Your files have been locked.<br>";
echo "This is only a simulation.";
